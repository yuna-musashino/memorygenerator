# MemoryGenerator

MemoryGenerator is a fun tool that generates random, fictional memories to spice up conversations with friends. Choose from themes such as childhood, adventure, or dream and get a unique memory each time!

## Features

- Generates diverse memory patterns (childhood, adventure, dream)
- Allows users to select the theme of the memory
- Option to share the generated memory with friends

## Installation

You can install MemoryGenerator from PyPI:

```bash
pip install memorygenerator
